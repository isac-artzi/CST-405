Unoptimized Three-Address Code (TAC)
=====================================
Intermediate representation with functions

  1: FUNC_BEGIN sign_test
  2: PARAM x
  3: DECL result
  4: t0 = -1
  5: result = t0
  6: t0 = x > 0
  7: IF_FALSE t0 GOTO L1
  8: result = 7
  9: L1:
 10: RETURN result
 11: FUNC_END sign_test
 12: FUNC_BEGIN main
 13: DECL a
 14: DECL b
 15: DECL r
 16: a = 10
 17: b = 5
 18: r = 0
 19: t0 = a > b
 20: IF_FALSE t0 GOTO L3
 21: r = 1
 22: L3:
 23: PRINT r
 24: r = 0
 25: t0 = a > b
 26: IF_FALSE t0 GOTO L4
 27: r = 2
 28: GOTO L5
 29: L4:
 30: r = 99
 31: L5:
 32: PRINT r
 33: r = 0
 34: t0 = b > a
 35: IF_FALSE t0 GOTO L6
 36: r = 99
 37: GOTO L7
 38: L6:
 39: r = 3
 40: L7:
 41: PRINT r
 42: r = 0
 43: t0 = a > b
 44: IF_FALSE t0 GOTO L8
 45: t0 = a == 10
 46: IF_FALSE t0 GOTO L10
 47: r = 4
 48: GOTO L11
 49: L10:
 50: r = 99
 51: L11:
 52: GOTO L9
 53: L8:
 54: r = 99
 55: L9:
 56: PRINT r
 57: r = 0
 58: t0 = a < 5
 59: IF_FALSE t0 GOTO L12
 60: r = 99
 61: GOTO L13
 62: L12:
 63: t0 = a < 8
 64: IF_FALSE t0 GOTO L14
 65: r = 99
 66: GOTO L15
 67: L14:
 68: t0 = a < 15
 69: IF_FALSE t0 GOTO L16
 70: r = 5
 71: GOTO L17
 72: L16:
 73: r = 99
 74: L17:
 75: L15:
 76: L13:
 77: PRINT r
 78: r = 0
 79: t0 = b < a
 80: IF_FALSE t0 GOTO L19
 81: r = 6
 82: L19:
 83: PRINT r
 84: r = 0
 85: t0 = a <= 10
 86: IF_FALSE t0 GOTO L21
 87: r = 6
 88: L21:
 89: PRINT r
 90: r = 0
 91: t0 = a > b
 92: IF_FALSE t0 GOTO L23
 93: r = 6
 94: L23:
 95: PRINT r
 96: r = 0
 97: t0 = a >= 10
 98: IF_FALSE t0 GOTO L25
 99: r = 6
100: L25:
101: PRINT r
102: r = 0
103: t0 = a == 10
104: IF_FALSE t0 GOTO L27
105: r = 6
106: L27:
107: PRINT r
108: r = 0
109: t0 = a != b
110: IF_FALSE t0 GOTO L29
111: r = 6
112: L29:
113: PRINT r
114: ARG a
115: t0 = CALL sign_test, 1
116: r = t0
117: PRINT r
118: r = 0
119: t0 = a > b
120: IF_FALSE t0 GOTO L31
121: t0 = b > a
122: IF_FALSE t0 GOTO L32
123: r = 99
124: GOTO L33
125: L32:
126: r = 8
127: L33:
128: L31:
129: PRINT r
130: RETURN 0
131: FUNC_END main
