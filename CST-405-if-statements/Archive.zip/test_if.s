.data

.text
.globl main
main:
    # Allocate stack space
    addi $sp, $sp, -400
    j main_start       # Jump to main function


# Function: sign_test
func_sign_test:
    # Save return address and allocate local stack frame
    # Parameter 'x' at offset 0
    sw $a0, 0($sp)     # Store parameter 'x'
    # Declared 'result' at offset 4
    li $t0, 1         # Load constant 1
    neg $t1, $t0      # t0 = -1
    move $t0, $t1       # result = t0
    sw $t0, 4($sp)     # Store to 'result'
    lw $t2, 0($sp)     # Load variable 'x'
    li $t3, 0         # Load constant 0
    sgt $t1, $t2, $t3   # t0 = x GT 0
    beqz $t1, L1       # If false, jump to L1
    # Spill all live registers before branch
    li $t0, 7         # result = 7 (constant)
    sw $t0, 4($sp)     # Store to 'result'
L1:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 4($sp)     # Load return value 'result'
    move $v0, $t0       # Move to return register
    # Return from function
    # End of function sign_test
    # Restore and return
    jr $ra

# Function: main
main_start:
    # Declared 'a' at offset 0
    # Declared 'b' at offset 4
    # Declared 'r' at offset 8
    li $t0, 10         # a = 10 (constant)
    sw $t0, 0($sp)     # Store to 'a'
    li $t1, 5         # b = 5 (constant)
    sw $t1, 4($sp)     # Store to 'b'
    li $t2, 0         # r = 0 (constant)
    sw $t2, 8($sp)     # Store to 'r'
    sgt $t3, $t0, $t1   # t0 = a GT b
    beqz $t3, L3       # If false, jump to L3
    # Spill all live registers before branch
    li $t2, 1         # r = 1 (constant)
    sw $t2, 8($sp)     # Store to 'r'
L3:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    lw $t2, 4($sp)     # Load variable 'b'
    sgt $t3, $t1, $t2   # t0 = a GT b
    beqz $t3, L4       # If false, jump to L4
    # Spill all live registers before branch
    li $t0, 2         # r = 2 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L5              # Unconditional jump
L4:                    # Label / merge point
    # Invalidate register state at merge point
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L5:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 4($sp)     # Load variable 'b'
    lw $t2, 0($sp)     # Load variable 'a'
    sgt $t3, $t1, $t2   # t0 = b GT a
    beqz $t3, L6       # If false, jump to L6
    # Spill all live registers before branch
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L7              # Unconditional jump
L6:                    # Label / merge point
    # Invalidate register state at merge point
    li $t0, 3         # r = 3 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L7:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    lw $t2, 4($sp)     # Load variable 'b'
    sgt $t3, $t1, $t2   # t0 = a GT b
    beqz $t3, L8       # If false, jump to L8
    # Spill all live registers before branch
    lw $t1, 0($sp)     # Load variable 'a'
    li $t2, 10         # Load constant 10
    seq $t3, $t1, $t2   # t0 = a EQ 10
    beqz $t3, L10       # If false, jump to L10
    # Spill all live registers before branch
    li $t0, 4         # r = 4 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L11              # Unconditional jump
L10:                    # Label / merge point
    # Invalidate register state at merge point
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L11:                    # Label / merge point
    # Invalidate register state at merge point
    # Spill all live registers before branch
    j L9              # Unconditional jump
L8:                    # Label / merge point
    # Invalidate register state at merge point
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L9:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    li $t2, 5         # Load constant 5
    slt $t3, $t1, $t2   # t0 = a LT 5
    beqz $t3, L12       # If false, jump to L12
    # Spill all live registers before branch
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L13              # Unconditional jump
L12:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 0($sp)     # Load variable 'a'
    li $t1, 8         # Load constant 8
    slt $t2, $t0, $t1   # t0 = a LT 8
    beqz $t2, L14       # If false, jump to L14
    # Spill all live registers before branch
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L15              # Unconditional jump
L14:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 0($sp)     # Load variable 'a'
    li $t1, 15         # Load constant 15
    slt $t2, $t0, $t1   # t0 = a LT 15
    beqz $t2, L16       # If false, jump to L16
    # Spill all live registers before branch
    li $t0, 5         # r = 5 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L17              # Unconditional jump
L16:                    # Label / merge point
    # Invalidate register state at merge point
    li $t0, 99         # r = 99 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L17:                    # Label / merge point
    # Invalidate register state at merge point
L15:                    # Label / merge point
    # Invalidate register state at merge point
L13:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 4($sp)     # Load variable 'b'
    lw $t2, 0($sp)     # Load variable 'a'
    slt $t3, $t1, $t2   # t0 = b LT a
    beqz $t3, L19       # If false, jump to L19
    # Spill all live registers before branch
    li $t0, 6         # r = 6 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L19:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    li $t2, 10         # Load constant 10
    sle $t3, $t1, $t2   # t0 = a LE 10
    beqz $t3, L21       # If false, jump to L21
    # Spill all live registers before branch
    li $t0, 6         # r = 6 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L21:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    lw $t2, 4($sp)     # Load variable 'b'
    sgt $t3, $t1, $t2   # t0 = a GT b
    beqz $t3, L23       # If false, jump to L23
    # Spill all live registers before branch
    li $t0, 6         # r = 6 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L23:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    li $t2, 10         # Load constant 10
    sge $t3, $t1, $t2   # t0 = a GE 10
    beqz $t3, L25       # If false, jump to L25
    # Spill all live registers before branch
    li $t0, 6         # r = 6 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L25:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    li $t2, 10         # Load constant 10
    seq $t3, $t1, $t2   # t0 = a EQ 10
    beqz $t3, L27       # If false, jump to L27
    # Spill all live registers before branch
    li $t0, 6         # r = 6 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L27:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # r = 0 (constant)
    sw $t0, 8($sp)     # Store to 'r'
    lw $t1, 0($sp)     # Load variable 'a'
    lw $t2, 4($sp)     # Load variable 'b'
    sne $t3, $t1, $t2   # t0 = a NE b
    beqz $t3, L29       # If false, jump to L29
    # Spill all live registers before branch
    li $t0, 6         # r = 6 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L29:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    # Argument: a
    # Call function sign_test with 1 arguments
    lw $a0, 0($sp)     # Load argument 'a'
    jal func_sign_test
    move $t0, $v0      # Get return value
    move $t1, $t0       # r = t0
    sw $t1, 8($sp)     # Store to 'r'
    # Print integer
    move $a0, $t1
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t1, 0         # r = 0 (constant)
    sw $t1, 8($sp)     # Store to 'r'
    lw $t2, 0($sp)     # Load variable 'a'
    lw $t3, 4($sp)     # Load variable 'b'
    sgt $t0, $t2, $t3   # t0 = a GT b
    beqz $t0, L31       # If false, jump to L31
    # Spill all live registers before branch
    lw $t0, 4($sp)     # Load variable 'b'
    lw $t2, 0($sp)     # Load variable 'a'
    sgt $t3, $t0, $t2   # t0 = b GT a
    beqz $t3, L32       # If false, jump to L32
    # Spill all live registers before branch
    li $t1, 99         # r = 99 (constant)
    sw $t1, 8($sp)     # Store to 'r'
    # Spill all live registers before branch
    j L33              # Unconditional jump
L32:                    # Label / merge point
    # Invalidate register state at merge point
    li $t0, 8         # r = 8 (constant)
    sw $t0, 8($sp)     # Store to 'r'
L33:                    # Label / merge point
    # Invalidate register state at merge point
L31:                    # Label / merge point
    # Invalidate register state at merge point
    lw $t0, 8($sp)     # Load variable 'r' for print
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0         # Load return value
    move $v0, $t0       # Move to return register
    # Return from function
    # End of function main

    # Spill any remaining registers

    # Exit program
    addi $sp, $sp, 400
    li $v0, 10
    syscall
